import React from "react";
import "./dashboard.css";
import { Link } from "react-router-dom";
const Foot = () => {
  return (
    <>
      <div class="dash-footer-bar">
        <div class="copyright">
          <Link> copyright</Link>
        </div>
      </div>
    </>
  );
};

export default Foot;
