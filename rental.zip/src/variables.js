import img from "./image/new-one.jpg";
import img2 from "./image/new-two.jpg";
import img3 from "./image/new-three.jpg";
import img4 from "./image/client.jpeg";

export const products = ["Our Latest Products"];
export const latest = [
  {
    discount: "30",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img,
  },
  {
    discount: "37",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
  {
    discount: "16",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
  {
    discount: "10",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
  {
    discount: "30",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
];
export const featured = [
  {
    discount: "10",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
  {
    discount: "30",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
  {
    discount: "35",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
  {
    discount: "37",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
  {
    discount: "30",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
];
export const related = [
  {
    discount: "10",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
  {
    discount: "30",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
  {
    discount: "35",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
  {
    discount: "37",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
  {
    discount: "30",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
  {
    discount: "16",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
  {
    discount: "10",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img3,
  },
  {
    discount: "30",
    name: "SONY PXW-FS5M2 XDCAM S35 CAMERA",
    retail: "655",
    offer: "599",
    img: img2,
  },
];
export const client = [
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
  {
    name: "Danish akhtr",
    img: img4,
  },
];
